/**
created by NOD
pageBase
천재교육 진도 학습 콘텐츠 GNB 메뉴 및 플레이어 연동 관리
*/

( function ( sb ) {

    sb.init = function() {
        Util.log( "이러면 아니되오" );
    }

    sb.test = function() {
        Util.log( "WOW" );
    }

})( stepBase = stepBase || {} );
var stepBase;

