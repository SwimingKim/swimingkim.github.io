(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.깜빡이그래픽 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 레이어_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F5F5F5").ss(8.5,1,1).p("ACjADIADgDIiSiRACjADIiPCPAilAAIFIAD");
	this.shape.setTransform(35,35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.2)").s().p("AAdAdQBChAAYhTQgWBUhCBBIAAAAQhBBChUAWQBTgYBAhCg");
	this.shape_1.setTransform(56.8,56.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.024)").s().p("AkAD/QhdhdgMiAQAGAuASApQAZBJA7A7QBpBoCUAAQCUAABphoQBohpAAiUQAAiUhohpQg7g7hJgZQgpgSgugGQCAAMBdBdQBrBqAACWQAACWhqBqIAAgBIgBABIABAAQhqBqiWAAQiWAAhqhrgAEAEAg");
	this.shape_2.setTransform(36.5,36.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,0,0.122)").s().p("AkGDVQAfASAjAKQA1ASA+ABQCMAABkhlQBlhkAAiMQgBg+gTg1QgKgjgRgfQAyBQAABlQAACOhlBlQhlBliOAAQhlAAhQgyg");
	this.shape_3.setTransform(44.6,44.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(0,0,0,0.149)").s().p("AjjDRQAmALAqACQARACARAAQCLAABjhjIAAAAQBjhiAAiLQAAgSgCgRQgCgqgLgnQATA2AAA+QAACMhkBkQhkBliNAAQg9gBg1gTg");
	this.shape_4.setTransform(47.7,47.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(0,0,0,0.173)").s().p("Ai5C4IAVABQA0AAAvgNQBTgWBChCIAAAAQBChCAWhTQANgvAAg0IgBgVQACARAAARQAACMhjBiIAAAAQhiBjiMAAQgRAAgRgCg");
	this.shape_5.setTransform(51.5,51.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(0,0,0,0.047)").s().p("AkGDzQg7g7gahIQAPAkAXAfQAVAgAcAdQBoBoCTgBQCSABBnhoQBohngBiSQABiThohoQgdgcgggVQgfgXgkgPQBIAaA7A7QBpBpAACUQAACThpBpQhpBpiTAAQiUAAhphpg");
	this.shape_6.setTransform(37.4,37.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(0,0,0,0.075)").s().p("AkUDfQgdgcgVggQARAXAVAVIASAQQBlBjCPABQCQAABmhnQBnhmAAiQQgBiPhjhlIgQgSQgVgVgXgRQAgAVAcAdQBoBnAACTQAACShoBnQhnBoiSAAQiTAAhnhog");
	this.shape_7.setTransform(39.1,39.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFCC00").s().p("AgUFdQgqgCgmgLQgjgKgfgRQgigTgdgaIgSgQQgVgWgRgXQgXgfgPgkQgRgpgGguQgDgYAAgZQAAiQBmhnQBnhmCQAAQAZAAAYADQAuAGApARQAkAPAfAXQAXARAWAVIAQASQAaAdATAhQARAgAKAiQALAnACAqIABAUQAAA1gNAuQgYBThBBCQhCBBhTAYQguANg1AAIgUgBg");
	this.shape_8.setTransform(35,35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(0,0,0,0.098)").s().p("AkoDFQAeAbAhASQBQAzBlAAQCOgBBmhkQBkhmABiOQgBhlgyhQQgSghgbgeQBkBlAACPQAACQhmBnQhnBmiQAAQiPAAhlhkg");
	this.shape_9.setTransform(41.7,41.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.깜빡이그래픽, new cjs.Rectangle(0,0,72.6,72.6), null);


(lib.common_navi_prev_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 레이어 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(62,75,91,0.851)").s().p("AnBHCIAAnNQAEiyCAiAQB/iACzgEIGbAAQAaAAAYAEIAAN/g");
	this.shape.setTransform(45,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({skewY:180},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90,90);


(lib.common_navi_circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 레이어 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0094D9").s().p("Aj3D4QhmhnAAiRQAAiQBmhnQBnhmCQAAQCRAABnBmQBmBnAACQQAACRhmBnQhnBmiRAAQiQAAhnhmg");
	this.shape.setTransform(35,35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.224)").s().p("AjoDoQhghgAAiIQAAiHBghhQBhhgCHAAQCIAABgBgQBhBhAACHQAACIhgBgIgBABQhgBgiIAAQiHAAhhhhgAjljlQheBfAACGQAACHBeBeQBfBfCGABQCHAABehfIABgBQBfheAAiHQgBiGhfhfQheheiHAAQiGAAhfBeg");
	this.shape_1.setTransform(36.4,36.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.122)").s().p("AjzD0QhlhlAAiPQAAiOBkhlIABgBQBlhkCOAAQCPAABlBlQBlBlAACOQAACPhlBlQhlBliPAAQiOAAhlhlgAjwjxIgBABQhkBjABCNQAACNBkBkQBjBkCNABQCNAABkhlQBlhkAAiNQgBiNhkhjQhkhkiNAAIgCAAQiMAAhiBjg");
	this.shape_2.setTransform(36.4,36.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,0,0.149)").s().p("AjxDxQhjhkAAiNQgBiNBjhkIABgBQBkhjCNABQCNAABkBjQBjBkABCNQAACNhkBkQhkBkiNAAQiNgBhkhjgAjujuQhjBiAACMQAACLBjBjQBiBjCMAAQCLAABjhjIAAAAQBjhjAAiLQAAiMhjhiQhjhjiLAAQiMAAhiBjIAAAAg");
	this.shape_3.setTransform(36.4,36.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(0,0,0,0.024)").s().p("Aj/EAQhqhqAAiWQAAiVBphqIABAAIAAgBQBqhpCVAAQCWAABqBqQBqBqAACVQAACXhqBpIAAAAIAAAAIAAAAQhpBqiXAAQiVAAhqhqgAAAllQiTAAhpBoIgBABQhoBpAACTQAACUBpBpQBpBpCTAAQCUAABphpQBphpAAiUQAAiThphpQhohpiUAAIgBAAg");
	this.shape_4.setTransform(36.4,36.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(0,0,0,0.047)").s().p("Aj8D9QhphpAAiUQAAiTBohpIABgBQBphoCTAAQCUAABpBpQBpBpAACTQAACUhpBpQhpBpiUAAQiTAAhphpgAj5j6IgBABQhnBnAACSQAACTBoBnQBnBoCSgBQCTABBnhoQBohngBiTQABiShohnQhnhoiTAAQiSAAhnBng");
	this.shape_5.setTransform(36.4,36.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(0,0,0,0.098)").s().p("Aj3D3QhlhmgBiRQABiRBkhmIABgBQBmhkCRgBQCRABBmBlQBmBmABCRQgBCRhmBmQhmBmiRABQiRgBhmhmgAjzj0IgBABQhlBkABCPQgBCOBmBmQBkBlCPAAQCOAABmhlQBlhmAAiOQAAiPhlhkQhmhmiOABQiPgBhkBlg");
	this.shape_6.setTransform(36.4,36.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(0,0,0,0.075)").s().p("Aj5D6QhohnAAiTQAAiSBnhnIABgBQBnhnCSAAQCTAABnBoQBoBnAACSQAACThoBnQhnBoiTAAQiSAAhnhogAj2j3IgBABQhlBmAACQQAACRBmBmQBmBmCQABQCRAABmhnQBnhmAAiRQgBiQhmhmQhmhmiRAAQiQAAhmBlg");
	this.shape_7.setTransform(36.4,36.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(0,0,0,0.2)").s().p("AjrDrQhhhhAAiKQAAiKBhhhQBhhhCKAAQCKAABhBhQBhBhABCKQAACKhiBhIAAAAQhhBiiKAAQiKgBhhhhgAjojoQhgBhAACHQAACIBgBgQBhBgCHAAQCIAABghfIABgBQBfhgAAiIQAAiHhghhQhghgiIAAQiHAAhhBgg");
	this.shape_8.setTransform(36.4,36.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(0,0,0,0.173)").s().p("AjuDuQhihiAAiMQAAiLBihiIAAgBIABAAQBihiCLAAQCMAABiBiQBjBjAACLQAACMhiBiIgBABQhiBiiMAAQiLAAhjhjgAjrjrQhhBhAACKQAACKBhBhQBhBhCKABQCKAABhhhIABgBQBhhhAAiKQgBiKhhhhQhhhhiKAAQiKAAhhBhg");
	this.shape_9.setTransform(36.4,36.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(0,0,0,0.302)").s().p("AjfDgQhdhdABiDQgBiCBchdIABgBQBdhcCCABQCDgBBdBdQBcBcAACDQAACDhcBdQhdBciDAAQiDAAhchcg");
	this.shape_10.setTransform(36.4,36.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(0,0,0,0.275)").s().p("AjiDjQhdheAAiFQAAiEBcheIABgBQBehcCEAAQCFAABeBdQBdBeAACEQAACFhdBeQheBdiFAAQiEAAhehdgAjfjgIgBABQhcBdABCCQgBCDBdBdQBcBcCDAAQCDAABdhcQBchdAAiDQAAiDhchcQhdhdiDABIgCAAQiBAAhcBbg");
	this.shape_11.setTransform(36.4,36.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(0,0,0,0.251)").s().p("AjlDkQheheAAiGQAAiGBehfQBfheCGAAQCGAABeBeQBgBfAACGQAACGhfBeIgBABQheBfiGAAQiGAAhfhggAjijjIgBABQhdBdAACFQAACFBeBdQBdBeCFAAQCFAABdheQBehdAAiFQAAiFhehdQhdheiFAAQiFAAhdBdg");
	this.shape_12.setTransform(36.4,36.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,72.6,72.6);


(lib.common_navi_check = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 레이어 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F5F5F5").ss(8.5,1,1).p("ACchxIjQDjIhnh8");
	this.shape.setTransform(18.8,15.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#F5F5F5").ss(8.5,1,1).p("ACjADIiPCPACjADIADgDIiSiRAilAAIFIAD");
	this.shape_1.setTransform(16.6,14.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#F5F5F5").ss(8.5,1,1).p("AgTiRIiSCRIADADICPCPACmAAIlIAD");
	this.shape_2.setTransform(16.6,14.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0.1,39.7,31.3);


(lib.깜빡이 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 레이어_1
	this.instance = new lib.깜빡이그래픽();
	this.instance.parent = this;
	this.instance.setTransform(36.3,36.3,1,1,0,0,0,36.3,36.3);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},10).wait(10).to({alpha:0},9).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,72.6,72.6);


(lib.common_navi_prev_button2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 레이어 2
	this.instance = new lib.common_navi_check("single",2);
	this.instance.parent = this;
	this.instance.setTransform(46.5,45,1,1,0,0,0,18.1,14.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({startPosition:2},14).to({startPosition:2},15).wait(1));

	// 레이어 3
	this.instance_1 = new lib.common_navi_circle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(46.3,46.3,1,1,0,0,0,36.3,36.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({startPosition:0},14).to({startPosition:0},15).wait(1));

	// 레이어 5
	this.instance_2 = new lib.common_navi_prev_bg("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(45,45,1,1,0,0,0,45,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90,90);


(lib.common_navi_prev = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// 레이어 3
	this.instance = new lib.common_navi_check("single",2);
	this.instance.parent = this;
	this.instance.setTransform(46.5,45,1,1,0,0,0,18.1,14.6);

	this.instance_1 = new lib.common_navi_circle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(46.3,46.3,1,1,0,0,0,36.3,36.3);

	this.instance_2 = new lib.common_navi_prev_bg("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(45,45,1,1,0,0,0,45,45);

	this.instance_3 = new lib.common_navi_prev_button2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(45,45,1,1,0,0,0,45,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90,90);


(lib.common_navi_next_button복사본 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 레이어 1
	this.instance = new lib.common_navi_check("single",1);
	this.instance.parent = this;
	this.instance.setTransform(46.5,45,1,1,0,0,0,18.1,14.6);

	this.mcNextGuide = new lib.깜빡이();
	this.mcNextGuide.name = "mcNextGuide";
	this.mcNextGuide.parent = this;
	this.mcNextGuide.setTransform(46.3,46.3,1,1,0,0,0,36.3,36.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.mcNextGuide}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,regX:36.3,regY:36.3,x:46.3,y:46.3,mode:"independent"},1).wait(1));

	// 레이어 4
	this.instance_1 = new lib.common_navi_circle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(46.3,46.3,1,1,0,0,0,36.3,36.3);

	this.instance_2 = new lib.common_navi_check("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(46.5,45,1,1,0,0,0,18.1,14.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_1},{t:this.instance_2}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({startPosition:0},1).wait(1));

	// 레이어 5
	this.instance_3 = new lib.common_navi_prev_bg("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(45,45,1,1,0,0,0,45,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({startPosition:0},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90,90);


// stage content:
(lib.gnb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 레이어_1
	this.mcNext = new lib.common_navi_next_button복사본();
	this.mcNext.name = "mcNext";
	this.mcNext.parent = this;
	this.mcNext.setTransform(1235.5,755,1,1,0,0,0,45.5,45);

	this.mcPrev = new lib.common_navi_prev();
	this.mcPrev.name = "mcPrev";
	this.mcPrev.parent = this;
	this.mcPrev.setTransform(45.5,755,1,1,0,0,0,45.5,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mcPrev},{t:this.mcNext}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(640,1110,1280,90);
// library properties:
lib.properties = {
	id: '2ADFE754B0ED6145B62490A7F11FA02B',
	width: 1280,
	height: 800,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2ADFE754B0ED6145B62490A7F11FA02B'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;